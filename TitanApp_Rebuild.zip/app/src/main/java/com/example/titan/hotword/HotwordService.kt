package com.example.titan.hotword

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class HotwordService : Service() {
    private val CH = "titan_hotword"
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CH) == null) {
                nm.createNotificationChannel(NotificationChannel(CH, "Titan listening", NotificationManager.IMPORTANCE_MIN))
            }
        }
        val notif = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Titan is listening")
            .setOngoing(true).build()
        startForeground(42, notif)
        // TODO: start VAD/STT here
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
