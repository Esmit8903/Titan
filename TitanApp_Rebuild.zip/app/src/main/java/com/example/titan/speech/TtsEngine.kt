package com.example.titan.speech

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

object TtsEngine {
    private var tts: TextToSpeech? = null
    private var ready = false

    fun init(ctx: Context, onReady: (() -> Unit)? = null) {
        if (tts != null) { onReady?.invoke(); return }
        tts = TextToSpeech(ctx.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            tts?.language = Locale.US
            tts?.setPitch(0.9f); tts?.setSpeechRate(0.97f)
            onReady?.invoke()
        }
    }
    fun speak(text: String) { if (ready) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "titan_greeting") }
    fun shutdown() { tts?.shutdown(); tts = null; ready = false }
}
