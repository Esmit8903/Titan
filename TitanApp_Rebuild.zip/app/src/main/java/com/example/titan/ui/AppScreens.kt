package com.example.titan.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun AppScreens() {
    var show by remember { mutableStateOf("home") }
    when (show) {
        "home" -> HomeScreen(onSettings = { show = "settings" })
        "settings" -> SettingsScreen(onBack = { show = "home" })
    }
}

@Composable
private fun HomeScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    Scaffold(topBar = {
        TopAppBar(title = { Text("Titan") }, actions = { TextButton(onClick = onSettings) { Text("Settings") } })
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState())) {
            OutlinedTextField(value=input,onValueChange={input=it},label={Text("Ask Titan…")},modifier=Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Button(onClick={ output = "You said: " + input }) { Text("Send") }
            Spacer(Modifier.height(12.dp))
            Text(output.ifBlank { "(No response yet)" })
        }
    }
}
