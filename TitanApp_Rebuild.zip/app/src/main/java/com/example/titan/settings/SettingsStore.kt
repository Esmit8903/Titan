package com.example.titan.settings

import android.content.Context

object SettingsStore {
    private const val PREFS = "titan_settings"
    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun setStartupGreetingEnabled(ctx: Context, on: Boolean) = p(ctx).edit().putBoolean("startup_greeting", on).apply()
    fun isStartupGreetingEnabled(ctx: Context) = p(ctx).getBoolean("startup_greeting", true)
}
