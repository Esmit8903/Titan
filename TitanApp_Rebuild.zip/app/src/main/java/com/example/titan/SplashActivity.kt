package com.example.titan

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import com.example.titan.settings.SettingsStore
import com.example.titan.speech.TtsEngine

class SplashActivity : Activity() {
    private var player: MediaPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
        setContentView(R.layout.activity_splash)
        TtsEngine.init(this)

        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val ringerOk = audio.ringerMode == AudioManager.RINGER_MODE_NORMAL
        if (ringerOk) {
            player = MediaPlayer.create(this, R.raw.boot_chime)
            player?.start()
        }

        Handler(Looper.getMainLooper()).postDelayed({
            if (ringerOk && SettingsStore.isStartupGreetingEnabled(this)) {
                TtsEngine.speak("Titan is ready to rule")
            }
            startActivity(Intent(this, MainActivity::class.java)); finish()
        }, 2000)
    }
    override fun onDestroy() { super.onDestroy(); player?.release(); player=null }
}
